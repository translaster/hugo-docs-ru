---
title: Render hooks
linkTitle: In this section
description: Create render hooks to override the rendering of Markdown to HTML.
categories: []
keywords: []
menu:
  docs:
    identifier: render-hooks-in-this-section
    parent: render-hooks
    weight: 10
weight: 10
showSectionMenu: false
aliases: [/templates/render-hooks/]
---

Create render hooks to override the rendering of Markdown to HTML.
