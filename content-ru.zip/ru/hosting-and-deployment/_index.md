---
title: Hosting and deployment
linkTitle: In this section
description: Site builds, automated deployments, and popular hosting solutions.
categories: []
keywords: []
menu:
  docs:
    identifier: hosting-and-deployment-in-this-section
    parent: hosting-and-deployment
    weight: 1
weight: 1
---

Because Hugo renders *static* websites, you can host your new Hugo website virtually anywhere. The following represent only a few of the more popular hosting and automated deployment solutions used by the Hugo community.
