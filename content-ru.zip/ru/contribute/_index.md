---
title: Contribute to the Hugo project
linkTitle: In this section
description: Contribute to Hugo development, documentation, and themes.
categories: []
keywords: []
menu:
  docs:
    identifier: contribute-in-this-section
    parent: contribute
    weight: 10
weight: 10
aliases: [/tutorials/how-to-contribute-to-hugo/,/community/contributing/]
---

Hugo relies heavily on the enthusiasm and participation of the open-source community. We need your support.
