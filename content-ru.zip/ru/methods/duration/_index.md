---
title: Duration methods
linkTitle: Duration
description: Use these methods with time.Duration values.
categories: []
keywords: []
menu:
  docs:
    parent: methods
---

Use these methods with time.Duration values.
