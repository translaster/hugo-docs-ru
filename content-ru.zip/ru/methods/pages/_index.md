---
title: Pages methods
linkTitle: Pages
description: Use these methods with a collection of Page objects.
categories: []
keywords: []
menu:
  docs:
    parent: methods
aliases: [/variables/pages]
---

Use these methods with a collection of Page objects.
