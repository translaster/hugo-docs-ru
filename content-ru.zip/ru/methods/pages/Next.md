---
title: Next
description: Returns the next page in a page collection, relative to the given page.
categories: []
keywords: []
action:
  related:
    - methods/pages/Prev
    - methods/page/Next
    - methods/page/Prev
    - methods/page/NextInSection
    - methods/page/PrevInSection
  returnType: page.Page
  signatures: [PAGES.Next PAGE]
---

{{% include "methods/pages/_common/next-and-prev.md" %}}
