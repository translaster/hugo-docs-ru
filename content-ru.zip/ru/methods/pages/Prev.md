---
title: Prev
description: Returns the previous page in a page collection, relative to the given page.
categories: []
keywords: []
action:
  related:
    - methods/pages/Next
    - methods/page/Next
    - methods/page/Prev
    - methods/page/NextInSection
    - methods/page/PrevInSection
  returnType: page.Pages
  signatures: [PAGES.Prev PAGE]
---

{{% include "methods/pages/_common/next-and-prev.md" %}}
