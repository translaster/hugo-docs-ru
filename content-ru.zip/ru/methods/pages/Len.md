---
title: Len
description: Returns the number of pages in the given page collection.
categories: []
keywords: []
action:
  related: []
  returnType: int
  signatures: [PAGES.Len]
---

```go-html-template
{{ .Pages.Len }} → 42
```
