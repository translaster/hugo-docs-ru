---
title: Resource methods
linkTitle: Resource
description: Use these methods with global, page, and remote Resource objects.
categories: []
keywords: []
menu:
  docs:
    parent: methods
---

Use these methods with global, page, and remote Resource objects.
