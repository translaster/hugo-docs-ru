---
# Do not remove front matter.
---

{{% note %}}

Use this method with [global], [page], or [remote] resources.

[global]: /getting-started/glossary/#global-resource
[page]: /getting-started/glossary/#page-resource
[remote]: /getting-started/glossary/#remote-resource

{{% /note %}}
