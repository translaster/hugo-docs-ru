---
title: Shortcode methods
linkTitle: Shortcode
description: Use these methods in your shortcode templates.
categories: []
keywords: []
menu:
  docs:
    parent: methods
---

Use these methods in your shortcode templates.
