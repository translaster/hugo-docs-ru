---
title: Site
description: Returns the Site object.
categories: []
keywords: []
action:
  related:
    - methods/page/Sites
  returnType: page.siteWrapper
  signatures: [SHORTCODE.Site]
---

See [Site methods].

[Site methods]: /methods/site/

```go-html-template
{{ .Site.Title }}
```
