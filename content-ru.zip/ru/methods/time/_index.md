---
title: Time methods
linkTitle: Time
description: Use these methods with time.Time values.
categories: []
keywords: []
menu:
  docs:
    identifier: time-methods
    parent: methods
---

Use these methods with time.Time values.
