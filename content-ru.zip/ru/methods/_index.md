---
title: Methods
linkTitle: In this section
description: A list of Hugo template methods including examples.
categories: []
keywords: []
menu:
  docs:
    identifier: methods-in-this-section
    parent: methods
    weight: 10
weight: 10
showSectionMenu: true
aliases: ['/variables/']
---

Use these methods within your templates.
