---
title: Post
description: Returns the `post` property of the given menu entry. 
categories: []
keywords: []
action:
  related:
    - methods/menu-entry/Pre
  returnType: template.HTML
  signatures: [MENUENTRY.Post]
---

{{% include "methods/menu-entry/_common/pre-post.md" %}}
