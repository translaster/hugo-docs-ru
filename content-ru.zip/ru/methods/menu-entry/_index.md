---
title: Menu entry methods
linkTitle: Menu entry
description: Use these methods in your menu templates.
categories: []
keywords: []
menu:
  docs:
    parent: methods
---

Use these methods in your menu templates.
