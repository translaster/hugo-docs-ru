---
title: Pre
description:  Returns the `pre` property of the given menu entry. 
categories: []
keywords: []
action:
  related:
    - methods/menu-entry/Post
  returnType: template.HTML
  signatures: [MENUENTRY.Pre]
---

{{% include "methods/menu-entry/_common/pre-post.md" %}}
