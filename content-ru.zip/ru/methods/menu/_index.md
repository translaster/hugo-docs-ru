---
title: Menu methods
linkTitle: Menu
description: Use these methods when ranging through menu entries.
categories: []
keywords: []
menu:
  docs:
    parent: methods
---

Use these methods when ranging through menu entries.
