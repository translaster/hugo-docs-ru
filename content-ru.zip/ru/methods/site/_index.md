---
title: Site methods
linkTitle: Site
description: Use these methods with Site objects.
categories: []
keywords: []
menu:
  docs:
    parent: methods
aliases: [/variables/site/]
---

Use these methods with Site objects. A multilingual project will have two or more sites, one for each language.
