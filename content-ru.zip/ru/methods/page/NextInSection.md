---
title: NextInSection
description: Returns the next regular page in a section, relative to the given page. 
categories: []
keywords: []
action:
  related:
    - methods/page/PrevInSection
    - methods/pages/Next
    - methods/pages/Prev
  returnType: page.Page
  signatures: [PAGE.NextInSection]
---

{{% include "methods/page/_common/nextinsection-and-previnsection.md" %}}
