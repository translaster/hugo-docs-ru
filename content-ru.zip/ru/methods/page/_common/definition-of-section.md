---
# Do not remove front matter.
---

A _section_ is a top-level content directory, or any content directory with an&nbsp;_index.md&nbsp;file.
