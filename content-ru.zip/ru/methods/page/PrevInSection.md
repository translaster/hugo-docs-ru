---
title: PrevInSection
description: Returns the previous regular page in a section, relative to the given page. 
categories: []
keywords: []
action:
  related:
    - methods/page/NextInSection
    - methods/pages/Next
    - methods/pages/Prev
  returnType: page.Page
  signatures: [PAGE.PrevInSection]
---

{{% include "methods/page/_common/nextinsection-and-previnsection.md" %}}
