---
title: Page methods
linkTitle: Page
description: Use these methods with a Page object.
categories: []
keywords: []
menu:
  docs:
    parent: methods
aliases: [/variables/page/]
---

Use these methods with a Page object.
