---
title: Len
description: Returns the length, in bytes, of the rendered content of the given page.
categories: []
keywords: []
action:
  related:
    - methods/page/Content
  returnType: int
  signatures: [PAGE.Len]
---

```go-html-template
{{ .Len }} → 42
```
