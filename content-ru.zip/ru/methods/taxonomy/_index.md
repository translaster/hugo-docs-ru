---
title: Taxonomy methods
linkTitle: Taxonomy
description: Use these methods with Taxonomy objects.
keywords: []
menu:
  docs:
    identifier:
    parent: methods
aliases: [/variables/taxonomy/]
---

Use these methods with Taxonomy objects.
