---
title: Pager methods
linkTitle: Pager
description: Use these methods with Pager objects when paginating a list page.
keywords: []
menu:
  docs:
    identifier:
    parent: methods
---

Use these methods with Pager objects when building navigation for a [paginated] list page.

[paginated]: /templates/pagination/
