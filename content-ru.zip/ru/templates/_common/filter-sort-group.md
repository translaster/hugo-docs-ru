---
# Do not remove front matter.
---

{{% note %}}
The [page collections quick reference guide] describes methods and functions to filter, sort, and group page collections.

[page collections quick reference guide]: /quick-reference/page-collections/
{{% /note %}}
