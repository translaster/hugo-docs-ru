---
title: Functions
description: A quick reference guide to Hugo's functions, grouped by namespace. Aliases, if any, appear in parentheses to the right of the function name.
categories: [quick reference]
keywords: []
menu:
  docs:
    parent: quick-reference
    weight: 30
weight: 30
toc: true
---

{{% quick-reference section="functions" %}}
