
**Overmind Studios** is a visual effects studio headquartered in Southern Germany.

The site is built by:

* [Tobias Kummer](https://www.overmind-studios.de/about/)

