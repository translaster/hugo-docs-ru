
Forestry.io is a Git-backed CMS (content management system) for websites and web products built using static site generators such as Hugo.

Forestry bridges the gap between developers and their teams, by making development fun and easy, while providing powerful content management for their teams.
