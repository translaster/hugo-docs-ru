Bypass Censorship find and promote tools that provide Internet access to everyone.

The site is built by:

* [Leyla Avsar](https://www.leylaavsar.com/) (designer)
* [Fredrik Jonsson](https://xdeb.net/) (dev)
