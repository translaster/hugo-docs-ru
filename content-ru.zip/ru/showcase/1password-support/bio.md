
**1Password** is a password manager that keeps you safe online. It protects your secure information behind the one password only you know.

The [1Password Support](https://support.1password.com/) website was built from scratch with **Hugo** and enhanced with **React** and **Elasticsearch** to give us the best of both worlds: The simplicity and performance of a static site, with the richness of a hosted web app.
