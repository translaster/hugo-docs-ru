
__We are Ampio.__ We design and manufacture a building automation system that provides control, comfort, safety and reliability. Visit [our page](http://ampio.com/) to learn more about our solution!

__Ampio Knowledge Base__ is a service built and maintained with Hugo. It is a self-service support platform for our customers and certified installers. It also contains a complete portfolio of our modules---building blocks of the Ampio building automation system.

The site is built by:

* [@mgetka](https://github.com/mgetka), developer
* [@SteynAnna](https://github.com/SteynAnna), maintainer

and other members of the Ampio team responsible for content creation.
