
**Fireship.io** is an ecosystem of detailed and practical resources for developers who want to build and ship high-quality apps.

The site is built by:

* [Jeff Delaney](https://fireship.io/contributors/jeff-delaney/)
