**Hapticmedia** provides interactive 3D configurators for eCommerce.
