---
title: Installation
linkTitle: In this section
description: Install Hugo on macOS, Linux, Windows, BSD, and on any machine that can run the Go compiler tool chain.
aliases: [/getting-started/installing/]
categories: []
keywords: []
menu:
  docs:
    identifier: installation-in-this-section
    parent: installation
    weight: 10
weight: 10
---

Install Hugo on macOS, Linux, Windows, BSD, and on any machine that can run the Go compiler tool chain.
